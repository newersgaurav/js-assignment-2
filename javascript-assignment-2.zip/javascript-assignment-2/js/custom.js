function question1(){
	function person(name){
		this.name = name;
	}

	function employee(id,salary){
		this.id = id;
		this.salary = salary;
	}

	function developers(competency){
		this.competency = competency;
	}

	employee.prototype = new person("Gaurav");
	developers.prototype = new employee(3333,25000);
	var a = new developers("FEEN");

	console.log(a.name);
	console.log(a.id);
	console.log(a.salary);
	console.log(a.competency);
}

function question2(){
	var arr = [1,2,3,4,5];

	function printArray(x){
	  var i = 0;
	  var fn = setInterval(function(){
	    if(i >= x.length){
	      clearInterval(fn);
	    }
	    else{
	      console.log(x[i++]);
	    }
	  },3000);
	}

	printArray(arr);
}

function question3(){
	var object = {id: 3333, name: "GAURAV"};
	var fn = function(){
		return this.id;
	}
	var get = fn.call(object);
	console.log("result using call function " + get);

	var bind_fn = fn.bind(object);
	console.log("result using bind function " + bind_fn())
}

function question4(){
	function factorial(){
	  return [1, 2, 3, 4, 5].map(function(n) {
	    return !(n > 1) ? 1 : arguments.callee(n - 1) * n;
	});
	}

	console.log("factorial using arguments.callee  " + factorial());

	function average(){
	  var sum = 0;
	  for(let elem of arguments){
	    sum+=elem;
	  }
	return sum/arguments.length;
	}

	console.log("average using arguments.length   " + average(2,2));

	function sum(){
	  var sum=0;
	  for(let elem of arguments){
	    sum+=elem;
	  }
	return sum;
	}

	console.log("sum of arguments by iterating the arguments   " + sum());
}

function question5(){
	var instance = 0;
	var invoke = 0;
	function test(){
		if(this === window){
			invoke++;
		}
		else{
			instance++;
		}
	}

	test();

	console.log("when function is called without using new keyword");
	console.log("instance count is " + instance + ", invoke count is " + invoke);

	new test();

	console.log("when function is called by using new keyword");
	console.log("instance count is " + instance + ", invoke count is " + invoke);
}

function question6(){
	function counter(){
	  let count = 1;
	  return function(){
	    count++;
	    console.log(count);
	  }
	}

	var b = counter();
	console.log("counter is increased by 1, count is ");
	b();
}